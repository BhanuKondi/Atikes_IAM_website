USE atikes_iam;

ALTER TABLE `user`
  ADD COLUMN `points` INT DEFAULT 0;

ALTER TABLE `question`
  ADD COLUMN `solution_answer_id` INT NULL,
  ADD KEY `ix_question_solution_answer_id` (`solution_answer_id`),
  ADD CONSTRAINT `fk_question_solution_answer`
    FOREIGN KEY (`solution_answer_id`) REFERENCES `answer` (`id`)
    ON DELETE SET NULL;
