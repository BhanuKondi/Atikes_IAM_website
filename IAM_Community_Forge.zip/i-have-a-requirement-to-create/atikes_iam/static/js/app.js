const navButton = document.querySelector("[data-nav-toggle]");
const nav = document.querySelector("[data-nav]");
const backButton = document.querySelector("[data-back]");

document.querySelectorAll(".flash").forEach((flash) => {
  window.setTimeout(() => {
    flash.classList.add("is-dismissing");
  }, 2500);
  window.setTimeout(() => {
    const wrap = flash.closest(".flash-wrap");
    flash.remove();
    if (wrap && !wrap.querySelector(".flash")) {
      wrap.remove();
    }
  }, 3100);
});

if (backButton) {
  backButton.addEventListener("click", () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = "/";
    }
  });
}

if (navButton && nav) {
  navButton.addEventListener("click", () => {
    nav.classList.toggle("open");
  });
}

const tagSelect = document.querySelector("[data-tag-select]");
const otherTagWrap = document.querySelector("[data-other-tag-wrap]");
const otherTag = document.querySelector("[data-other-tag]");

if (tagSelect && otherTagWrap && otherTag) {
  const syncOtherTag = () => {
    const isOther = tagSelect.value === "Other";
    otherTagWrap.classList.toggle("hidden", !isOther);
    otherTag.required = isOther;
    if (!isOther) {
      otherTag.value = "";
    }
  };
  tagSelect.addEventListener("change", syncOtherTag);
  syncOtherTag();
}

document.querySelectorAll("[data-submit-on-change]").forEach((field) => {
  field.addEventListener("change", () => {
    field.form?.submit();
  });
});

const profileToggle = document.querySelector("[data-profile-toggle]");
const profileMenu = document.querySelector("[data-profile-menu]");
if (profileToggle && profileMenu) {
  profileToggle.addEventListener("click", () => {
    profileMenu.classList.toggle("open");
  });
  document.addEventListener("click", (event) => {
    if (!profileToggle.contains(event.target) && !profileMenu.contains(event.target)) {
      profileMenu.classList.remove("open");
    }
  });
}

const carousel = document.querySelector("[data-carousel]");
if (carousel) {
  const slides = [...carousel.querySelectorAll("[data-slide]")];
  const previous = carousel.querySelector("[data-slide-prev]");
  const next = carousel.querySelector("[data-slide-next]");
  let activeIndex = 0;

  const showSlide = (index) => {
    if (!slides.length) return;
    activeIndex = (index + slides.length) % slides.length;
    slides.forEach((slide, slideIndex) => {
      slide.classList.toggle("active", slideIndex === activeIndex);
    });
  };

  previous?.addEventListener("click", (event) => {
    event.preventDefault();
    showSlide(activeIndex - 1);
  });

  next?.addEventListener("click", (event) => {
    event.preventDefault();
    showSlide(activeIndex + 1);
  });

  window.setInterval(() => showSlide(activeIndex + 1), 7000);
}

document.querySelectorAll("[data-format]").forEach((button) => {
  button.addEventListener("click", () => {
    const editor = document.querySelector("[data-rich-editor]");
    if (!editor) return;
    const tag = button.dataset.format === "bold" ? "**" : "_";
    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const selected = editor.value.slice(start, end) || "text";
    editor.value = `${editor.value.slice(0, start)}${tag}${selected}${tag}${editor.value.slice(end)}`;
    editor.focus();
    editor.selectionStart = start + tag.length;
    editor.selectionEnd = start + tag.length + selected.length;
  });
});

const eventBrowser = document.querySelector("[data-event-browser]");
if (eventBrowser) {
  const triggers = [...eventBrowser.querySelectorAll("[data-event-trigger]")];
  const details = [...eventBrowser.querySelectorAll("[data-event-detail]")];

  triggers.forEach((trigger) => {
    trigger.addEventListener("click", () => {
      const eventId = trigger.dataset.eventTrigger;
      triggers.forEach((item) => item.classList.toggle("active", item === trigger));
      details.forEach((detail) => {
        detail.classList.toggle("hidden", detail.dataset.eventDetail !== eventId);
      });
    });
  });
}

document.querySelectorAll("[data-inline-editor]").forEach((editor) => {
  const edit = editor.querySelector("[data-inline-edit]");
  const cancel = editor.querySelector("[data-inline-cancel]");
  const preview = editor.querySelector("[data-generated-preview]");
  const actions = editor.querySelector("[data-generated-actions]");
  const form = editor.querySelector("[data-generated-form]");

  edit?.addEventListener("click", () => {
    preview?.classList.add("hidden");
    actions?.classList.add("hidden");
    form?.classList.remove("hidden");
  });

  cancel?.addEventListener("click", () => {
    form?.classList.add("hidden");
    preview?.classList.remove("hidden");
    actions?.classList.remove("hidden");
  });
});

document.querySelectorAll("[data-reaction]").forEach((button) => {
  button.addEventListener("click", () => {
    const row = button.closest(".reaction-row");
    row?.querySelectorAll("[data-reaction]").forEach((item) => {
      item.classList.toggle("active", item === button);
    });
  });
});

document.querySelectorAll("[data-comment-action]").forEach((button) => {
  button.addEventListener("click", () => {
    const answer = button.closest(".inline-answer, .answer-card");
    const form = answer?.querySelector("[data-comment-form]");
    if (form) {
      form.classList.toggle("hidden");
      form.querySelector("textarea")?.focus();
    } else {
      document.querySelector("[data-answer-input]")?.focus();
    }
  });
});
