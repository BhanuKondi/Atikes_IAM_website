from pathlib import Path

from flask import Blueprint, abort, current_app, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from ..extensions import db
from ..models import Answer, AnswerComment, AnswerReaction, Question, QuestionAttachment, utcnow
from ..services.experts import refresh_expert_profile


qa_bp = Blueprint("qa", __name__, url_prefix="/qa")
ALLOWED_ATTACHMENTS = {"pdf", "jpg", "jpeg", "png", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "zip"}
REACTION_CHOICES = (
    ("love", "♥", "Love"),
    ("like", "👍", "Like"),
    ("dislike", "👎", "Dislike"),
)
POSITIVE_REACTIONS = {"love", "like"}
SOLUTION_POINTS = 50


def _award_points(user, points):
    if user and points:
        user.points = (user.points or 0) + points


def _question_tag_options(status):
    rows = Question.query.with_entities(Question.tags).filter_by(status=status).all()
    tags = set()
    for row in rows:
        for tag in (row.tags or "").split(","):
            clean_tag = tag.strip()
            if clean_tag:
                tags.add(clean_tag)
    return sorted(tags, key=str.lower)


def _answer_interactions(answers):
    answer_ids = [answer.id for answer in answers]
    interactions = {}
    if not answer_ids:
        return interactions
    reactions = AnswerReaction.query.filter(AnswerReaction.answer_id.in_(answer_ids)).all()
    comments = (
        AnswerComment.query.filter(AnswerComment.answer_id.in_(answer_ids))
        .order_by(AnswerComment.created_at.asc())
        .all()
    )
    for answer in answers:
        interactions[answer.id] = {
            "reactions": {
                key: {"symbol": symbol, "label": label, "names": [], "selected": False}
                for key, symbol, label in REACTION_CHOICES
            },
            "comments": [],
        }
    for reaction in reactions:
        bucket = interactions[reaction.answer_id]["reactions"].get(reaction.reaction_type)
        if bucket is None:
            continue
        bucket["names"].append(reaction.user.name)
        bucket["selected"] = bucket["selected"] or (
            current_user.is_authenticated and reaction.user_id == current_user.id
        )
    for comment in comments:
        interactions[comment.answer_id]["comments"].append(comment)
    return interactions


@qa_bp.route("/", methods=["GET", "POST"])
def questions():
    if request.method == "POST":
        if not current_user.is_authenticated:
            return redirect(url_for("auth.login", next=request.full_path))
        question_id = request.form.get("question_id", type=int)
        question = Question.query.filter_by(id=question_id, status="approved").first_or_404()
        body = request.form.get("body", "").strip()
        if len(body) < 3:
            flash("Please write an answer before posting.", "error")
        else:
            _post_approved_answer(question, body)
            flash("Answer posted successfully.", "success")
        return redirect(url_for("qa.questions", tab="published", question_id=question.id))

    tag = request.args.get("tag", "").strip().lower()
    search = request.args.get("q", "").strip()
    active_tab = request.args.get("tab", "published")
    is_admin = current_user.is_authenticated and current_user.is_admin
    if not is_admin or active_tab not in {"published", "pending"}:
        active_tab = "published"
    status = "pending" if active_tab == "pending" else "approved"

    query = Question.query.filter_by(status=status)
    if tag:
        query = query.filter(Question.tags.ilike(f"%{tag}%"))
    if search:
        pattern = f"%{search}%"
        query = query.filter(Question.title.ilike(pattern) | Question.body.ilike(pattern) | Question.tags.ilike(pattern))
    items = query.order_by(Question.created_at.desc()).all()
    selected_question_id = request.args.get("question_id", type=int)
    selected_question = None
    if selected_question_id:
        selected_question = next((question for question in items if question.id == selected_question_id), None)
    if selected_question is None and items:
        selected_question = items[0]
    selected_answers = []
    if selected_question:
        selected_answers = (
            Answer.query.filter_by(question_id=selected_question.id, status="approved")
            .order_by(Answer.created_at.desc())
            .all()
        )

    published_count = Question.query.filter_by(status="approved").count()
    pending_count = Question.query.filter_by(status="pending").count() if is_admin else 0
    tag_options = _question_tag_options(status)

    return render_template(
        "qa/list.html",
        questions=items,
        selected_question=selected_question,
        selected_answers=selected_answers,
        answer_interactions=_answer_interactions(selected_answers),
        reaction_choices=REACTION_CHOICES,
        active_tag=tag,
        tag_options=tag_options,
        active_tab=active_tab,
        published_count=published_count,
        pending_count=pending_count,
        search=search,
    )


@qa_bp.route("/ask", methods=["GET", "POST"])
@login_required
def ask_question():
    tag_options = ["SailPoint IIQ", "SailPoint IDN", "Okta", "Saviynt", "Ping Identity"]
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        body = request.form.get("body", "").strip()
        version = request.form.get("version", "").strip()
        tag_choice = request.form.get("tag_choice", "").strip()
        other_tag = request.form.get("other_tag", "").strip()
        tags = other_tag if tag_choice == "Other" else tag_choice
        if len(title) < 10 or len(body) < 20:
            flash("Please add a clear title and enough detail for experts to answer.", "error")
        elif not tags:
            flash("Please choose a tag or enter another IAM tag.", "error")
        else:
            question = Question(title=title, body=body, tags=tags, version=version, author=current_user)
            db.session.add(question)
            db.session.flush()
            _save_attachment(question)
            refresh_expert_profile(current_user)
            db.session.commit()
            flash("Question submitted for admin review.", "success")
            return redirect(url_for("qa.question_detail", question_id=question.id))
    return render_template("qa/ask.html", tag_options=tag_options)


def _save_attachment(question):
    upload_dir = Path(current_app.root_path) / "static" / "uploads" / "questions"
    upload_dir.mkdir(parents=True, exist_ok=True)
    for upload in request.files.getlist("attachments"):
        if not upload or not upload.filename:
            continue
        filename = secure_filename(upload.filename)
        extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if extension not in ALLOWED_ATTACHMENTS:
            flash(f"{filename} skipped. This file type is not allowed.", "error")
            continue
        stored_name = f"question-{question.id}-{len(question.attachments.all()) + 1}-{filename}"
        upload.save(upload_dir / stored_name)
        attachment = QuestionAttachment(
            question=question,
            filename=filename,
            file_path=f"uploads/questions/{stored_name}",
        )
        db.session.add(attachment)
        if not question.attachment_path:
            question.attachment_filename = filename
            question.attachment_path = attachment.file_path


def _post_approved_answer(question, body):
    answer = Answer(
        body=body,
        author=current_user,
        question=question,
        status="approved",
        approved_at=utcnow(),
        approved_by=current_user,
    )
    db.session.add(answer)
    db.session.flush()
    _award_points(current_user, 3)
    refresh_expert_profile(current_user)
    db.session.commit()
    return answer


@qa_bp.route("/<int:question_id>", methods=["GET", "POST"])
def question_detail(question_id):
    question = Question.query.get_or_404(question_id)
    can_view_pending = current_user.is_authenticated and (
        current_user.is_admin or question.author_id == current_user.id
    )
    if question.status != "approved" and not can_view_pending:
        abort(404)
    if request.method == "POST":
        if not current_user.is_authenticated:
            return redirect(url_for("auth.login", next=request.path))
        body = request.form.get("body", "").strip()
        if len(body) < 3:
            flash("Please write an answer before posting.", "error")
        else:
            _post_approved_answer(question, body)
            flash("Answer posted successfully.", "success")
            return redirect(url_for("qa.question_detail", question_id=question.id))
    answers_query = question.answers
    if not (current_user.is_authenticated and current_user.is_admin):
        answers_query = answers_query.filter_by(status="approved")
    answers = answers_query.order_by(Answer.created_at.desc()).all()
    return render_template(
        "qa/detail.html",
        question=question,
        answers=answers,
        answer_interactions=_answer_interactions(answers),
        reaction_choices=REACTION_CHOICES,
    )


@qa_bp.post("/answers/<int:answer_id>/react")
@login_required
def react_to_answer(answer_id):
    answer = Answer.query.filter_by(id=answer_id, status="approved").first_or_404()
    reaction_type = request.form.get("reaction_type", "").strip()
    if reaction_type not in {choice[0] for choice in REACTION_CHOICES}:
        abort(400)
    reaction = AnswerReaction.query.filter_by(answer_id=answer.id, user_id=current_user.id).first()
    previous_type = reaction.reaction_type if reaction else None
    if reaction is None:
        reaction = AnswerReaction(answer=answer, user=current_user, reaction_type=reaction_type)
        db.session.add(reaction)
    elif reaction.reaction_type == reaction_type:
        db.session.delete(reaction)
    else:
        reaction.reaction_type = reaction_type
    if current_user.id != answer.author_id:
        was_positive = previous_type in POSITIVE_REACTIONS
        is_positive = reaction_type in POSITIVE_REACTIONS and previous_type != reaction_type
        removed_positive = previous_type == reaction_type and previous_type in POSITIVE_REACTIONS
        if is_positive and not was_positive:
            _award_points(answer.author, 6)
        elif removed_positive:
            _award_points(answer.author, -6)
        elif was_positive and reaction_type not in POSITIVE_REACTIONS:
            _award_points(answer.author, -6)
    db.session.commit()
    return redirect(request.form.get("next") or url_for("qa.questions", question_id=answer.question_id))


@qa_bp.post("/answers/<int:answer_id>/comment")
@login_required
def comment_on_answer(answer_id):
    answer = Answer.query.filter_by(id=answer_id, status="approved").first_or_404()
    body = request.form.get("body", "").strip()
    if len(body) < 2:
        flash("Please write a comment before posting.", "error")
    else:
        db.session.add(AnswerComment(answer=answer, user=current_user, body=body))
        _award_points(current_user, 3)
        db.session.commit()
    return redirect(request.form.get("next") or url_for("qa.questions", question_id=answer.question_id))


@qa_bp.post("/answers/<int:answer_id>/solution")
@login_required
def mark_solution(answer_id):
    answer = Answer.query.filter_by(id=answer_id, status="approved").first_or_404()
    question = answer.question
    if question.author_id != current_user.id and not current_user.is_admin:
        abort(403)

    previous_solution = question.solution_answer
    if question.solution_answer_id == answer.id:
        question.solution_answer_id = None
        _award_points(answer.author, -SOLUTION_POINTS)
    else:
        if previous_solution is not None:
            _award_points(previous_solution.author, -SOLUTION_POINTS)
        question.solution_answer_id = answer.id
        _award_points(answer.author, SOLUTION_POINTS)

    db.session.commit()
    flash("Solution updated.", "success")
    return redirect(request.form.get("next") or url_for("qa.questions", question_id=question.id))
