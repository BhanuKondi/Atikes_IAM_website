USE atikes_iam;

CREATE TABLE IF NOT EXISTS `answer_reaction` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `reaction_type` VARCHAR(20) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `answer_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_answer_reaction_user` (`answer_id`, `user_id`),
  KEY `ix_answer_reaction_reaction_type` (`reaction_type`),
  KEY `ix_answer_reaction_answer_id` (`answer_id`),
  KEY `ix_answer_reaction_user_id` (`user_id`),
  CONSTRAINT `fk_answer_reaction_answer`
    FOREIGN KEY (`answer_id`) REFERENCES `answer` (`id`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_answer_reaction_user`
    FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `answer_comment` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `body` TEXT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `answer_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_answer_comment_created_at` (`created_at`),
  KEY `ix_answer_comment_answer_id` (`answer_id`),
  KEY `ix_answer_comment_user_id` (`user_id`),
  CONSTRAINT `fk_answer_comment_answer`
    FOREIGN KEY (`answer_id`) REFERENCES `answer` (`id`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_answer_comment_user`
    FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
